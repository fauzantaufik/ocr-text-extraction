import os
from extraction import Extractor

if __name__ == '__main__':
    extractor = Extractor()
    pdf_file = os.path.join(extractor.base_dir, 'csi1.pdf')
    extractor.extract(pdf_file)